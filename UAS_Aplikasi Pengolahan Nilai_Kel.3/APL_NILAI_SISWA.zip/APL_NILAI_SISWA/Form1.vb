﻿Imports System.Data.SqlClient

Public Class Form1
    Dim conn As New SqlConnection("Data Source=.\SQLEXPRESS;Initial Catalog=DB_NilaiSiswa;Integrated Security=True")
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim da As SqlDataAdapter
    Dim dt As DataTable

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        tampilkanData()
        isiComboBox()
    End Sub

    Sub isiComboBox()
        Try
            If conn.State = ConnectionState.Open Then conn.Close()
            conn.Open()

            ' NIM Mahasiswa
            cmbNIM.Items.Clear()
            cmd = New SqlCommand("SELECT NIM FROM Mahasiswa", conn)
            dr = cmd.ExecuteReader()
            While dr.Read()
                cmbNIM.Items.Add(dr("NIM").ToString())
            End While
            dr.Close()

            ' Kode Mata Kuliah
            cmbKodeMatkul.Items.Clear()
            cmd = New SqlCommand("SELECT KodeMatkul FROM MataKuliah", conn)
            dr = cmd.ExecuteReader()
            While dr.Read()
                cmbKodeMatkul.Items.Add(dr("KodeMatkul").ToString())
            End While
            dr.Close()

            ' Kode Nilai
            cmbKodeNilai.Items.Clear()
            cmd = New SqlCommand("SELECT KodeNilai FROM Nilai", conn)
            dr = cmd.ExecuteReader()
            While dr.Read()
                cmbKodeNilai.Items.Add(dr("KodeNilai").ToString())
            End While
            dr.Close()

        Catch ex As Exception
            MessageBox.Show("Gagal isi ComboBox: " & ex.Message)
        Finally
            If conn.State = ConnectionState.Open Then conn.Close()
        End Try
    End Sub

    Sub tampilkanData()
        Try
            If conn.State = ConnectionState.Open Then conn.Close()
            conn.Open()
            dgvNilai.AutoGenerateColumns = True ' WAJIB ADA!
            da = New SqlDataAdapter("SELECT * FROM Nilai", conn)
            dt = New DataTable()
            da.Fill(dt)
            dgvNilai.DataSource = dt
        Catch ex As Exception
            MessageBox.Show("Gagal tampil data: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub

    Private Sub cmbNIM_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbNIM.SelectedIndexChanged
        Try
            If conn.State = ConnectionState.Open Then conn.Close()
            conn.Open()
            cmd = New SqlCommand("SELECT Nama, Kelas FROM Mahasiswa WHERE NIM = @nim", conn)
            cmd.Parameters.AddWithValue("@nim", cmbNIM.Text)
            dr = cmd.ExecuteReader()
            If dr.Read() Then
                txtNama.Text = dr("Nama").ToString()
                txtKelas.Text = dr("Kelas").ToString()
            End If
            dr.Close()
        Catch ex As Exception
            MessageBox.Show("Gagal ambil data mahasiswa: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub

    Private Sub cmbKodeMatkul_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbKodeMatkul.SelectedIndexChanged
        Try
            If conn.State = ConnectionState.Open Then conn.Close()
            conn.Open()
            Dim query As String = "SELECT m.NamaMatkul, d.NamaDosen, m.SKS FROM MataKuliah m JOIN Dosen d ON m.KodeDosen = d.KodeDosen WHERE m.KodeMatkul = @kode"
            cmd = New SqlCommand(query, conn)
            cmd.Parameters.AddWithValue("@kode", cmbKodeMatkul.Text)
            dr = cmd.ExecuteReader()
            If dr.Read() Then
                txtMataKuliah.Text = dr("NamaMatkul").ToString()
                txtDosen.Text = dr("NamaDosen").ToString()
                txtSks.Text = dr("SKS").ToString()
            End If
            dr.Close()
        Catch ex As Exception
            MessageBox.Show("Gagal tampil data matkul: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub

    Private Sub txtNilaiPraktek_TextChanged(sender As Object, e As EventArgs) Handles txtNilaiPraktek.TextChanged
        If IsNumeric(txtNilaiTeori.Text) AndAlso IsNumeric(txtNilaiPraktek.Text) Then
            Dim rata2 As Double = (Val(txtNilaiTeori.Text) + Val(txtNilaiPraktek.Text)) / 2
            txtRataRata.Text = Math.Round(rata2, 2)
        End If
    End Sub

    Private Sub btnNew_Click(sender As Object, e As EventArgs) Handles btnNew.Click
        cmbKodeNilai.Text = ""
        cmbNIM.Text = ""
        txtNama.Clear()
        txtKelas.Clear()
        cmbKodeMatkul.Text = ""
        txtMataKuliah.Clear()
        txtDosen.Clear()
        txtSks.Clear()
        txtNilaiTeori.Clear()
        txtNilaiPraktek.Clear()
        txtRataRata.Clear()
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If cmbKodeNilai.Text = "" Or cmbNIM.Text = "" Or cmbKodeMatkul.Text = "" Then
            MessageBox.Show("Semua field harus diisi!", "Validasi", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        Try
            If conn.State = ConnectionState.Open Then conn.Close()
            conn.Open()
            cmd = New SqlCommand("INSERT INTO Nilai (KodeNilai, NIM, KodeMatkul, NilaiTeori, NilaiPraktek, RataRata) VALUES (@kode, @nim, @matkul, @teori, @praktek, @rata)", conn)
            cmd.Parameters.AddWithValue("@kode", cmbKodeNilai.Text)
            cmd.Parameters.AddWithValue("@nim", cmbNIM.Text)
            cmd.Parameters.AddWithValue("@matkul", cmbKodeMatkul.Text)
            cmd.Parameters.AddWithValue("@teori", txtNilaiTeori.Text)
            cmd.Parameters.AddWithValue("@praktek", txtNilaiPraktek.Text)
            cmd.Parameters.AddWithValue("@rata", txtRataRata.Text)
            cmd.ExecuteNonQuery()
            MessageBox.Show("Data berhasil disimpan!", "Sukses", MessageBoxButtons.OK, MessageBoxIcon.Information)
            tampilkanData()
            isiComboBox()
            btnNew.PerformClick()

        Catch ex As Exception
            MessageBox.Show("Gagal simpan data: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If String.IsNullOrWhiteSpace(cmbKodeNilai.Text) Then
            MessageBox.Show("Pilih data dari tabel terlebih dahulu!", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        If MessageBox.Show("Yakin ingin menghapus data dengan kode: " & cmbKodeNilai.Text & "?", "Konfirmasi", MessageBoxButtons.YesNo) = DialogResult.Yes Then
            Try
                If conn.State = ConnectionState.Open Then conn.Close()
                conn.Open()
                cmd = New SqlCommand("DELETE FROM Nilai WHERE KodeNilai = @kode", conn)
                cmd.Parameters.AddWithValue("@kode", cmbKodeNilai.Text)
                Dim rowsAffected As Integer = cmd.ExecuteNonQuery()
                conn.Close()

                If rowsAffected > 0 Then
                    MessageBox.Show("Data berhasil dihapus!", "Sukses", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    tampilkanData()
                    isiComboBox()
                    btnNew.PerformClick()
                Else
                    MessageBox.Show("Data tidak ditemukan atau tidak berhasil dihapus!", "Info")
                End If
            Catch ex As Exception
                MessageBox.Show("Gagal hapus data: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Finally
                conn.Close()
            End Try
        End If
    End Sub

    Private Sub btnRefresh_Click(sender As Object, e As EventArgs) Handles btnRefresh.Click
        tampilkanData()
        isiComboBox()
    End Sub

    Private Sub dgvNilai_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvNilai.CellClick
        Dim i As Integer = dgvNilai.CurrentRow.Index
        cmbKodeNilai.Text = dgvNilai.Item(0, i).Value.ToString()
        cmbNIM.Text = dgvNilai.Item(1, i).Value.ToString()
        cmbKodeMatkul.Text = dgvNilai.Item(2, i).Value.ToString()
        txtNilaiTeori.Text = dgvNilai.Item(3, i).Value.ToString()
        txtNilaiPraktek.Text = dgvNilai.Item(4, i).Value.ToString()
        txtRataRata.Text = dgvNilai.Item(5, i).Value.ToString()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            If conn.State = ConnectionState.Open Then conn.Close()
            conn.Open()
            MessageBox.Show("Koneksi Berhasil!")
        Catch ex As Exception
            MessageBox.Show("Koneksi gagal: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub

    Private Sub cmbKodeNilai_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbKodeNilai.SelectedIndexChanged

    End Sub

    Private Sub dgvNilai_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvNilai.CellContentClick

    End Sub

    Private Sub Label10_Click(sender As Object, e As EventArgs) Handles Label10.Click

    End Sub
End Class